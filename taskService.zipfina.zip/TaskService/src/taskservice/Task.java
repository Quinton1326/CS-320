package taskservice;

public class Task {

}
